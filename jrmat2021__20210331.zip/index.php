<?php
// inicializace vseho potrebneho
require_once(__DIR__ . "/includes/page_init.php");

//if ( C_USER_ID > 0 ) redirect("/home");

$body_class ="login_page";

// vykresleni zahlavi
include_once(__DIR__ . "/includes/_header_empty.php");
?>

    <div class="welcome">

        <p class="taCenter"><img src="/img/logo_gray.png" width="426" height="174" alt="CRAMS logo"></p>

        <p class="popis">
            Systém <strong>CRAMS</strong> (<em>Car Rental and Management System</em>) je jednoduše ovladatelný systém pro firmy, který bude umožňovat správu rezervací a dat o vozidlech a řidičích. Data jsou pořizována prostřednictvím webového rozhraní a uchovávána v relační databázi MYSQL.
        </p>

        <p class="buttons">
            <a href="registration_request.php">Žádost o registraci do systému</a>
            <a href="login.php">Přihlášení</a>
            <a target="_blank" href="/dokumentace/DELTA_Maturitni_projekt_dokumentace_Rousek_Jakub_20210331.pdf">Dokumentace (Adobe PDF)</a>
            <a target="_blank" href="/dokumentace/DELTA_Maturitni_projekt_dokumentace_Rousek_Jakub_20210331.docx">Dokumentace (MS Word)</a>
        </p>

    </div>

<?php
// vykresleni zapati
include_once(__DIR__ . "/includes/_footer_empty.php");

?>