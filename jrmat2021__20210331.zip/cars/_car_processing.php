<?php
    $id = $rz = $company_id = $vyrobce = $model = $spotreba = $tachometr = $stk_od = $stk_do = $pojisteni_od = $pojisteni_do = $palivo = "";

    // overeni, byla data odeslana a ze se jedna o data z naseho formulare

    if ( POST("add_car") == "submit" ) {

        // formular byl odeslany, muzeme validovat
        $id = POST('id');
        $company_id = POST('company_id');
        $rz = POST("plate_number");
        $vyrobce = POST("manufacturer");
        $palivo = POST("fuel_type");
        $model = POST('model');
        $tachometr = POST('travelled_kilometers');
        $spotreba = POST("consumption_by_manufacturer");
        $stk_do = POST("vehicle_inspection_validity_till");
        $pojisteni_do = POST("insurance_validity_till");

        // validate odeslanych dat
        // vyplnenost
        if( $company_id == "" || $palivo == "" || $rz == "" || $vyrobce == "" || $model == "" || $stk_do == "" || $pojisteni_do == ""){
            // chybove hlaseni uzivateli
            $err = "Prosíme, vyplňte všechny položky formuláře.";
            print_r($_POST);
        } else {

            if ( Validator::ValidujWhitelist($rz) === false ) $err = "RZ obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($vyrobce) === false ) $err = "Výrobce obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($model) === false ) $err = "Model obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($stk_do) === false ) $err = "platnost STK obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($pojisteni_do) === false ) $err = "Platnost pojištění obsahuje nepovolené znaky";

            // pokud se jedna o nove auto, RZ nesmi existovat v DB
            if ( $new_car === true ) {
                if ( is_existing_car_plate_number($rz) === true ) $err = "Tuto RZ již v systému evidujeme.";
            }

            // TODO pokud prijde v POSTu id vozidla, jedna se o upravu a id musi existovat, kontrola na podvrzeni auta
            // TODO mela by jeste byt kontrola na opravnenost upravy vozidla ( belong to neco)

            // validace id spolecnosti
            if ( $err == "" ) {

                // u admina validujeme existenci spolecnosti
                if ( C_USER_IS_ADMIN ) {
                    if ( !is_existing_company($company_id) ) $err = "Nevalidni identifikator společnosti";
                } elseif ( C_USER_IS_MANAGER ) {
                    // u managera validujeme existenci spolecnosti a jeji prislusnost
                    if ( !is_existing_company($company_id) || !is_company_belong_to_user($company_id, C_USER_ID) ) $err = "Nevalidni identifikator společnosti";
                }
            }
                
            if ( $err == "" ) {

                // data jsou validni muzeme je zpracovat
                $url = "";

                // pokud se jedna o nove auto, pouzivame insert into
                if ( $new_car === true ) {
                    $id = UUID::v5();
                    $q = "INSERT INTO " . C_TABLE_VEHICLES . "(id, company_id, plate_number, fuel_type, producer, model, consumption_by_manufacturer, travelled_kilometers, vehicle_inspection_validity_since, vehicle_inspection_validity_till, insurance_validity_since, insurance_validity_till) VALUES (?, ?, ?, ?, ?, ?, ?, ?, now(), ?, now(), ?)";
                    $pars = [$id, $company_id, $rz, $palivo, $vyrobce, $model, $spotreba, $tachometr, $stk_do . " 00:00:00", $pojisteni_do . " 00:00:00"];
                    //print_r($pars); die();
                    $result = db_execute($q, $pars);
                } else {
                    $q = "UPDATE " . C_TABLE_VEHICLES . " set company_id = ?, plate_number = ?, fuel_type = ?, producer = ?, model = ?, consumption_by_manufacturer = ?, travelled_kilometers = ?, vehicle_inspection_validity_till = ?, insurance_validity_till = ? where id = ?;";
                    $pars = [$company_id, $rz, $palivo, $vyrobce, $model, $spotreba, $tachometr, $stk_do . " 00:00:00", $pojisteni_do . " 00:00:00", $id];
                    $result = db_execute($q, $pars);
                } 
    
                if ( $result === false ) {
                    $err = "Chyba při zpracování údajů";
                } else {
                    //bylo zapsano 
                    $msg = "Data byla uložena.";
                    //hlaseni o vysledku akce a nasledny redirect.
                    redirect("index.php?msg_success=" . urlencode($msg));
                }            
    
            }

        }

    } else {
        
        if ( $new_car === false ) {
            
            // nacist id auta z GETu
            $id = GET("id");

            // nacist udaje o aute z DB
            $data = nacti_auto($id);
            if ( $data === false ) $err = "Chyba při načítání dat o vozidle";
            else {
                $rz = strtoupper($data["plate_number"]);
                $company_id = $data["company_id"];
                $vyrobce = $data["producer"];
                $model = $data["model"];
                $spotreba = $data["consumption_by_manufacturer"];
                $tachometr = $data["travelled_kilometers"];
                $stk_do = str_replace(" 00:00:00", "", $data["vehicle_inspection_validity_till"]);
                $pojisteni_do = str_replace(" 00:00:00", "", $data["vehicle_inspection_validity_till"]);
                $palivo = $data["fuel_type"];
            }
            
        }

    }

?>