<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "vehicles";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$arr_pars = array();

$q = "SELECT * FROM ". C_TABLE_VEHICLES;
if( C_USER_ROLE == C_ROLE_MANAGER || C_USER_ROLE == C_ROLE_USER){
    $q .= " WHERE company_id = ? "; 
    $arr_pars[] = C_USER_COMPANY_ID;
}

$q .= " ORDER BY fuel_type DESC";

//$data = db_execute("SELECT * FROM ". C_TABLE_USERS ." ORDER BY create_date DESC");
$data = db_execute($q, $arr_pars);

$arr_data = $data->fetchAll();
//print_r($arr_data);


include_once(__DIR__ . "/../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../includes/_msg.php");
?>

<?php if( C_USER_IS_MANAGER || C_USER_IS_ADMIN){?>
<p class="pb10"><a href="add_car.php" class="a-btn a-btn-new">Přidat vozidlo</a></p>
<?php }?>

<table class="data-table data">  
    <thead>
        <tr>
            <td>RZ</td>
            <td>Výrobce</td>
            <td>Model</td>
            <td>Palivo</td>
            <td class="taRight">Spotřeba v TP (l/100 km)</td>
            <td class="taRight">Spotřeba reálná (l/100 km)</td>
            <td class="taRight">Stav tachometru (km)</td>
            <td class="taRight">Platnost STK</td>
            <td class="taRight">Platnost pojistky</td>

        </tr>
    </thead>
    
    <?php 

        foreach($arr_data as $radek) {

            $dtInsuranceTill = new DateTime($radek['insurance_validity_till']);
            $dtInspectionTill = new DateTime($radek['vehicle_inspection_validity_till']);
            $id = $radek['id'];

    ?>
        
        <tr>
         <td><a href="edit_car.php?id=<?php echo($id);?>"><?php echo($radek['plate_number']);?></a></td>
         <td><?php echo($radek['producer']);?></td>
         <td><?php echo($radek['model']);?></td>
         <td><?php echo($radek['fuel_type']);?></td>
         <td class="taRight"><?php echo($radek['consumption_by_manufacturer']);?> </td>
         <td class="taRight"><?php if($radek['consumption_real'] == null) echo("Žádná data"); else {echo($radek['consumption_real']);} ;?></td>
         <td class="taRight"><?php echo(number_format($radek['travelled_kilometers'], 0, '' , " "));?></td>
         <td class="taRight"><?php echo($dtInsuranceTill->format("j. n. Y"));?></td>
         <td class="taRight"><?php echo($dtInspectionTill->format("j. n. Y"));?></td>

        
        </tr>
    <?php
        }
    ?>
</table>

<?php
include_once(__DIR__ . "/../includes/_footer.php");
?>
