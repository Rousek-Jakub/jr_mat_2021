<?php 

$companies = nacti_firmy();

if($err != ""){echo($err);}
?>

<form method="POST" action="" class="data">

    <input type="hidden" name="id" value="<?php echo($id); ?>">

    <table class="simple-form-table">
        <tr>
            <td>RZ:</td>
            <td><input type="text" name="plate_number" placeholder="Číslo RZ" value="<?php echo($rz);?>"></td>
        </tr>
        <tr>
            <td>Výrobce:</td>
            <td><input type="text" name="manufacturer" placeholder="Výrobce" value="<?php echo($vyrobce);?>"></td>
        </tr>
        <tr>
            <td>Model:</td>
            <td><input type="text" name="model" placeholder="Model" value="<?php echo($model);?>"></td>
        </tr>
        <tr>
            <td>Spotřeba v TP:</td>
            <td><input type="text" name="consumption_by_manufacturer" placeholder="Spotřeba v TP" value="<?php echo($spotreba);?>"></td>
        </tr>
        <tr>
            <td>Stav tachometru (km):</td>
            <td><input type="text" name="travelled_kilometers" placeholder="Stav tachometru (km)" value="<?php echo($tachometr);?>"></td>
        </tr>
        <tr>
            <td>STK platná do:</td>
            <td><input type="date" name="vehicle_inspection_validity_till" placeholder="asdasd" value="<?php echo($stk_do);?>"></td>
        </tr>
        <tr>
            <td>Pojištění do:</td>
            <td><input type="date" name="insurance_validity_till" placeholder="asdasd" value="<?php echo($pojisteni_do);?>"></td>
        </tr>
        <tr>
            <td>Palivo:</td>
            <td>
            <select name="fuel_type">
                <option value="<?php echo(C_FUEL_TYPE_DIESEL); ?>" <?php if ( $palivo == C_FUEL_TYPE_DIESEL ) echo(" selected"); ?>>Nafta</option>
                <option value="<?php echo(C_FUEL_TYPE_PETROL); ?>" <?php if ( $palivo == C_FUEL_TYPE_PETROL ) echo(" selected"); ?>>Benzín</option>
                <option value="<?php echo(C_FUEL_TYPE_LPG); ?>" <?php if ( $palivo == C_FUEL_TYPE_LPG ) echo(" selected"); ?>>LPG</option>
                <option value="<?php echo(C_FUEL_TYPE_CNG); ?>" <?php if ( $palivo == C_FUEL_TYPE_CNG ) echo(" selected"); ?>>CNG</option>
                <option value="<?php echo(C_FUEL_TYPE_EE); ?>" <?php if ( $palivo == C_FUEL_TYPE_EE ) echo(" selected"); ?>>Elektrická energie</option>
            </select>
            </td>
        </tr>
        <?php if ( C_USER_IS_ADMIN ) { ?>
            <tr>
                <td>Společnost:</td>
                <td>
                <select name="company_id" >
                <?php foreach($companies as $radek) { $cid = $radek['id']; ?>
                    <option value="<?php echo($cid); ?>" <?php if ( $cid == $company_id ) echo(" selected"); ?> > <?php echo($radek['company_name']); ?> </option>
                <?php } ?>
                </select>
                </td>
        <?php } ?>
    </table>

    <button type="submit" name="add_car" value="submit">Uložit</button>

</form>