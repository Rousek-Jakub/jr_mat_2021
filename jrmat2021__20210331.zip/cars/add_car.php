<?php
require_once(__DIR__ . "/../includes/page_init.php");

//overeni typu uzivatele a jeho prava
require_user_login();

$section = "vehicles";

$new_car = true;

include_once(__DIR__ . "/_car_processing.php");

include_once(__DIR__ . "/../includes/_header.php");
include_once(__DIR__ . "/../includes/_msg.php");

?>  

<h1>Vytvoření nového vozidla</h1>

<?php
include_once(__DIR__ . "/_car_form.php");
include_once(__DIR__ . "/../includes/_footer.php");
?>
