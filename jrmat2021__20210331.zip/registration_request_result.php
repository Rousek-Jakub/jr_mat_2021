<?php
require_once(__DIR__ . "/includes/page_init.php");

$body_class = "login_page";
include_once(__DIR__ . "/includes/_header_empty.php");

?>
    <p class="taCenter mt50"><img src="/img/logo_gray.png" width="426" height="174" alt="CRAMS logo"></p>

    <div class="welcome">

        <p class="msg msg_success">Váš požadavek byl přijat ke zpracování.</p>
        <p>Vyčkejte, prosíme, na vyřízení Vaší žádosti.</p>

    </div>


<?php
include_once(__DIR__ . "/includes/_footer_empty.php");
?>