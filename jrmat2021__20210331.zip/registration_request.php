<?php

// inicializace vseho potrebneho
require_once(__DIR__ . "/includes/page_init.php");

// zpracování odeslaných dat
include_once(__DIR__ . "/_registration_request_processing.php");
 
// vykresleni zahlavi
$body_class ="login_page";

include_once(__DIR__ . "/includes/_header_empty.php");

?>
	<p class="taCenter mt50"><img src="/img/logo_gray.png" width="426" height="174" alt="CRAMS logo"></p>
<?php

// vykreslení formuláře
include_once(__DIR__ . "/_registration_request_form.php");

// vykresleni zapati
include_once(__DIR__ . "/includes/_footer_empty.php");

?>