<?php

// inicializace vseho potrebneho
require_once(__DIR__ . "/includes/page_init.php");

session_destroy();

redirect("/");
