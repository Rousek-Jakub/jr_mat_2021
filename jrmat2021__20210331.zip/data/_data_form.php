<?php 

$companies = nacti_firmy();

if($err != ""){echo($err);}
?>

<form method="POST" action="" class="data">

    <input type="hidden" name="id" value="<?php echo($id); ?>">

    <table class="simple-form-table">
    <tr>
            <td>Vozidlo:</td>
            <td>
            <select name="vehicle_id">
                <?php
                    foreach ($cars as $radek){
                        ?> 
                        <option value="<?php echo($radek['id']) ?>" <?php if($vehicle_id == $radek['id']) echo('selected')?> > <?php echo($radek['plate_number'] . " " . $radek['producer'] . " " . $radek['model'] . " (" . get_company_name_by_id($radek['company_id']) . ")") ?> </option>
                        <?php
                    }
                ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>Uživatel:</td>
            <td>
            <select name="user_id">
            <?php
                    foreach ($users as $radek){
                        ?> 
                        <option value="<?php echo($radek['id']) ?>" <?php if($user_id == $radek['id']) echo('selected')?> > <?php echo($radek['surname'] . " " . $radek['name'] . " (" . get_company_name_by_id($radek['company_id']) . ")") ?> </option>
                        <?php
                    }
                ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>Natankováno (l):</td>
            <td><input type="text" name="refuelled_litres" placeholder="Natankováno (l)" value="<?php echo($refuelled_litres);?>"></td>
        </tr>
        <tr>
            <td>Cena (1l):</td>
            <td><input type="text" name="price_per_litre" placeholder="cena (1l)" value="<?php echo($price_per_litre);?>"></td>
        </tr>
        <tr>
            <td>Stav tachometru (km):</td>
            <td><input type="text" name="tachometer_kilometres" placeholder="Stav tachometru (km)" value="<?php echo($tachometer_kilometres);?>"></td>
        </tr>
        <tr>
            <td>Místo tankování:</td>
            <td><input type="text" name="refueling_place" placeholder="Místo tankování" value="<?php echo($refueling_place  );?>"></td>
        </tr>
        <tr>
            <td>Palivo:</td>
            <td>
            <select name="fuel_type">
                <option value="<?php echo(C_FUEL_TYPE_DIESEL); ?>" <?php if ( $palivo == C_FUEL_TYPE_DIESEL ) echo(" selected"); ?>>Nafta</option>
                <option value="<?php echo(C_FUEL_TYPE_PETROL); ?>" <?php if ( $palivo == C_FUEL_TYPE_PETROL ) echo(" selected"); ?>>Benzín</option>
                <option value="<?php echo(C_FUEL_TYPE_LPG); ?>" <?php if ( $palivo == C_FUEL_TYPE_LPG ) echo(" selected"); ?>>LPG</option>
                <option value="<?php echo(C_FUEL_TYPE_CNG); ?>" <?php if ( $palivo == C_FUEL_TYPE_CNG ) echo(" selected"); ?>>CNG</option>
                <option value="<?php echo(C_FUEL_TYPE_EE); ?>" <?php if ( $palivo == C_FUEL_TYPE_EE ) echo(" selected"); ?>>Elektrická energie</option>
            </select>
            </td>
        </tr>
        <?php if ( C_USER_IS_ADMIN ) { ?>
            <tr>
                <td>Společnost:</td>
                <td>
                <select name="company_id" >
                <?php foreach($companies as $radek) { $cid = $radek['id']; ?>
                    <option value="<?php echo($cid); ?>" <?php if ( $cid == $company_id ) echo(" selected"); ?> > <?php echo($radek['company_name']); ?> </option>
                <?php } ?>
                </select>
                </td>
        <?php } ?>
    </table>

    <button type="submit" name="add_data" value="submit">Uložit</button>

</form>