<?php $id = $palivo = $vehicle_id = $fuel_type = $refueling_place = $price_per_litre = $refuelled_litres =$tachometer_kilometres = $user_id  =  "";

if(C_USER_IS_ADMIN){    
    $cars = get_all_cars();
    $users = get_all_users();
} else if (C_USER_IS_MANAGER){
    $cars = get_company_cars(C_USER_COMPANY_ID);
    $users = get_company_users(C_USER_COMPANY_ID);
} else {
    $cars = get_user_reserved_cars(C_USER_ID);
    $users = get_user(C_USER_ID);
}


if ( POST("add_data") == "submit" ) {
    //print_r($_POST);
    // formular byl odeslany, muzeme validovat
    $id = POST('id');
    $user_id = POST('user_id');
    $vehicle_id = POST('vehicle_id');
    $refuelled_litres = POST('refuelled_litres');
    $price_per_litre = POST('price_per_litre');
    $tachometer_kilometres = POST('tachometer_kilometres');
    $refueling_place = POST('refueling_place');
    $fuel_type = POST('fuel_type');

    // validate odeslanych dat
    // vyplnenost
    if( $vehicle_id == "" || $user_id == "" || $refuelled_litres == "" || $price_per_litre == "" || $tachometer_kilometres == "" || $refueling_place == "" || $fuel_type == "" ){
        // chybove hlaseni uzivateli
        $err = "Prosíme, vyplňte všechny položky formuláře.";
        //print_r($_POST);
        die;
    } else {
    
        if ( $new_data === false ) {
            if ( is_existing_data($id) === false ) $err = "Tato data rezervaci v systému neevidujeme.";
        }

        //kontrola jestli userid a vehicle id spolu souvisi
        if($err == ""){
            if(belong_to_same_company($user_id, $vehicle_id) === false) $err = "Vybrané vozidlo a uživatel nespadají pod stejnou společnost";
        }


        if ( $err == "" ) {


            // pokud se jedna o nove auto, pouzivame insert into
            if ( $new_DATA === true ) {
                $id = UUID::v5();
                //$q = "INSERT INTO " . C_TABLE_RESERVATIONS . "(id, vehicle_id, user_id, since, till, create_date) VALUES (?, ?, ?, ?, ?, now())";
                //$pars = [$id, $vehicle_id, $user_id, $reservation_since, $reservation_till];
                //print_r($pars); die();
                $result = db_execute($q, $pars);
            } else {
                //$q = "UPDATE " . C_TABLE_RESERVATIONS . " set vehicle_id = ?, user_id = ?, since = ?, till = ? WHERE id = ?;";
                //$pars = [$vehicle_id, $user_id, $reservation_since, $reservation_till, $id];
                //$result = db_execute($q, $pars);
            } 

            if ( $result === false ) {
                $err = "Chyba při zpracování údajů";
            } else {
                //bylo zapsano 
                $msg = "Data byla uložena.";
                //hlaseni o vysledku akce a nasledny redirect.
                redirect("index.php?msg_success=" . urlencode($msg));
            }            

        }

    }

} else {
    
    if ( $new_data === false ) {
        
        // nacist id auta z GETu
        $id = GET("id");

        // nacist udaje o aute z DB
        $data = nacti_data($id);
        if ( $data === false ) $err = "Chyba při načítání dat";
        else {
            print_r($data);
            $id = $data['id'];
            $vehicle_id = $data['vehicle_id'];
            $user_id =  $data['user_id'];
            $refuelled_litres =  $data['refuelled_litres'];
            $price_per_litre =  $data['price_per_litre'];
            $tachometer_kilometres =  $data['tachometer_kilometres'];
            $refueling_place =  $data['refueling_place'];
            $fuel_type_refueled =  $data['fuel_type_refueled'];
        }
        
    }
    else {


    }

}

?>



