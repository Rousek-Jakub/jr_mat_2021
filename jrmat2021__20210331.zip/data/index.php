<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "data";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$arr_pars = array();


//$q .= " ORDER BY fuel_type DESC";

//$data = db_execute("SELECT * FROM ". C_TABLE_DATA ." ORDER BY record_date DESC");


include_once(__DIR__ . "/../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../includes/_msg.php");
?>

<?php if ( C_USER_IS_ADMIN ) {
	$data = db_execute("SELECT * FROM " . C_TABLE_DATA . " ORDER BY record_date DESC");
}

if ( C_USER_IS_MANAGER ) {
	$data = db_execute("SELECT * FROM " . C_TABLE_DATA . " WHERE vehicle_id IN (SELECT id FROM " . C_TABLE_VEHICLES . " WHERE company_id = ?) ORDER BY record_date DESC", [C_USER_COMPANY_ID]);
}

if ( C_USER_IS_USER ) {
	$data = db_execute("SELECT * FROM " . C_TABLE_DATA . " WHERE user_id = ? ORDER BY record_date DESC", [C_USER_ID]);

}

$arr_data = $data->fetchAll();
//print_r($arr_data);

?>


<p class="pb10"><a href="add_data.php" class="a-btn a-btn-new">Přidat data</a></p>

<table class="data-table data">
    <thead>
    <tr>
        <td>Vozidlo</td>
        <td>Uživatel</td>
        <td class="taRight">Natankováno</td>
        <td class="taRight">Cena za 1 l</td>
        <td>Místo tankování</td>
        <td class="taRight">Stav tachometru</td>
        <td class="taRight">Datum pořízení dat</td>
        <td></td>
    </tr>
    </thead>

	<?php

	foreach ( $arr_data as $radek ) {
		$auto = nacti_auto($radek['vehicle_id']);
		$uzivatel = nacti_uzivatele($radek['user_id']);
		// print_r($uzivatel);
		$id = $radek['id'];
		$record_date = date_create($radek['record_date']);
		?>

        <tr>
            <td><?php echo($auto['producer'] . " " . $auto['model']); ?></a></td>
            <td><?php echo($uzivatel['name'] . " " . $uzivatel['surname']); ?></td>
            <td class="taRight"><?php echo(number_format($radek['refuelled_litres'], 2, ",", "")); ?> l</td>
            <td class="taRight"><?php echo(number_format($radek['price_per_litre'], 2, ",", "")); ?> Kč</td>
            <td><?php echo($radek['refueling_place']); ?> </td>
            <td class="taRight"><?php echo(number_format($radek['tachometer_kilometres'], 0, '', " ")); ?></td>
            <td class="taRight"><?php echo($record_date->format("j. n. Y")); ?></td>
            <td><a href="edit_data.php?id=<?php echo($id); ?>">Upravit</a></td>
        </tr>
		<?php
	}
	?>
</table>

<?php
include_once(__DIR__ . "/../includes/_footer.php");
?>
