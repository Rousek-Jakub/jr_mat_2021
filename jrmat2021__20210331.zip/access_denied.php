<?php

// inicializace vseho potrebneho
require_once(__DIR__ . "/includes/page_init.php");

// vykresleni zahlavi
$body_class ="login_page";

include_once(__DIR__ . "/includes/_header_empty.php");
?>
<p class="msg_error">Pro zobrazení tohoto obsahu nemáte dostatečná práva</p>
<?php

// vykresleni zapati
include_once(__DIR__ . "/includes/_footer_empty.php");



?>

