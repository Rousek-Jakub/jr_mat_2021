<?php
    $id = $cars = $reservation_till = $reservation_since = $company_id = $users = $user_id = $vehicle_id ="";
    if(C_USER_IS_ADMIN){    
        $cars = get_all_cars();
        $users = get_all_users();
    } else if (C_USER_IS_MANAGER){
        $cars = get_company_cars(C_USER_COMPANY_ID);
        $users = get_company_users(C_USER_COMPANY_ID);
    } else {
        $cars = get_company_cars(C_USER_COMPANY_ID);
        $users = get_user(C_USER_ID);
    }

    

    // overeni, byla data odeslana a ze se jedna o data z naseho formulare

    if ( POST("add_reservation") == "submit" ) {
        //print_r($_POST);
        // formular byl odeslany, muzeme validovat
        $id = POST('id');
        $vehicle_id = POST('vehicle_id');
        $user_id = POST('user_id');
        $reservation_since = POST('reservation_since');
        $reservation_till = POST('reservation_till');

        // validate odeslanych dat
        // vyplnenost
        if( $vehicle_id == "" || $user_id == "" || $reservation_since == "" || $reservation_till == ""){
            // chybove hlaseni uzivateli
            $err = "Prosíme, vyplňte všechny položky formuláře.";
            //print_r($_POST);
        } else {

        
            if ( $new_reservation === false ) {
                if ( is_existing_reservation($id) === false ) $err = "Tuto rezervaci v systému neevidujeme.";
            }

            //kontrola jestli userid a vehicle id spolu souvisi
            if($err == ""){
                if(belong_to_same_company($user_id, $vehicle_id) === false) $err = "Vybrané vozidlo a uživatel nespadají pod stejnou společnost";
            }
            if($err == ""){
                //kontrola validity datumů
                if(Validator::ValidujDatum($reservation_since) == false) $err = "Datum rezervace od není validní";
            }
            if($err == ""){
                //kontrola validity datumů
                if(Validator::ValidujDatum($reservation_till) == false) $err = "Datum rezervace od není validní";
            }
            if($err == ""){
                //kontrola validity časového rozmezí
                
                if(date_create($reservation_since) > date_create($reservation_till)) $err = "Rozsah datumů rezervace je neplatný";
            }
            //kontrola jestli 
            if($err == ""){
                $date_collision = get_date_collisions($reservation_since, $reservation_till, $vehicle_id, $id);
                if ( $date_collision === false ) $err = "Chyba při zpracování požadavku";
                else {
                    if ( is_array($date_collision) && count($date_collision) > 0 ) $err = "Rozsah datumů je v kolizi s jinou rezervací";
                }
            }

            if ( $err == "" ) {


                // pokud se jedna o nove auto, pouzivame insert into
                if ( $new_reservation === true ) {
                    $id = UUID::v5();
                    $q = "INSERT INTO " . C_TABLE_RESERVATIONS . "(id, vehicle_id, user_id, since, till, create_date) VALUES (?, ?, ?, ?, ?, now())";
                    $pars = [$id, $vehicle_id, $user_id, $reservation_since, $reservation_till];
                    //print_r($pars); die();
                    $result = db_execute($q, $pars);
                } else {
                    $q = "UPDATE " . C_TABLE_RESERVATIONS . " set vehicle_id = ?, user_id = ?, since = ?, till = ? WHERE id = ?;";
                    $pars = [$vehicle_id, $user_id, $reservation_since, $reservation_till, $id];
                    $result = db_execute($q, $pars);
                } 
    
                if ( $result === false ) {
                    $err = "Chyba při zpracování údajů";
                } else {
                    //bylo zapsano 
                    $msg = "Data byla uložena.";
                    //hlaseni o vysledku akce a nasledny redirect.
                    redirect("index.php?msg_success=" . urlencode($msg));
                }            
    
            }

        }

    } else {
        
        if ( $new_reservation === false ) {
            
            // nacist id auta z GETu
            $id = GET("id");

            // nacist udaje o aute z DB
            $data = nacti_rezervaci($id);
            if ( $data === false ) $err = "Chyba při načítání dat o rezervaci";
            else {
                $id = $data['id'];
                $vehicle_id = $data['vehicle_id'];
                $user_id =  $data['user_id'];
                $reservation_since = date_create($data['since'])->format("Y-m-d");
                $reservation_till = date_create($data['till'])->format("Y-m-d");
            }
            
        }
        else {
            // predvyplneni datumu
            $reservation_since = new DateTime();
            $reservation_since->add(new DateInterval("P1D"));
            $reservation_since = $reservation_since->format("Y-m-d");
            $reservation_till = new DateTime();
            $reservation_till->add(new DateInterval("P5D"));
            $reservation_till = $reservation_till->format("Y-m-d");

        }

    }

?>