<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "reservations";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$arr_pars = array();

$q = "SELECT * FROM ". C_TABLE_RESERVATIONS;
if ( C_USER_IS_ADMIN ) ;

if( C_USER_IS_MANAGER ){

    // 1. zpusob - definice sql s exaktnimi hodnotami s operatorem IN ( ... )
    //$q .= " WHERE vehicle_id IN ( 'jedna hodnota', 'druha hodnota', '', ''.... ) "; 
    //$arr_cars = get_company_cars_id(C_USER_COMPANY_ID);
    //$str_cars = "'" . implode("','", $arr_cars) . "'";
    //$q .= " WHERE vehicle_id IN ( $str_cars ) "; 

    // 2 zpusob - subquery
    $q .= " WHERE vehicle_id IN ( SELECT id FROM " . C_TABLE_VEHICLES . " WHERE company_id = ? ) ";
    $arr_pars[] = C_USER_COMPANY_ID;
}

if( C_USER_IS_USER ){

    // 2 zpusob - subquery
    $q .= " WHERE user_id = ? "; 
    $arr_pars[] = C_USER_ID;
}

$q .= " ORDER BY create_date DESC";

//$data = db_execute("SELECT * FROM ". C_TABLE_USERS ." ORDER BY create_date DESC");
$data = db_execute($q, $arr_pars);
$arr_data = $data->fetchAll();
//print_r($arr_data); 



include_once(__DIR__ . "/../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../includes/_msg.php");
?>

<?php //if( check_user_role('spravce') || check_user_role('superadmin')){?>
<p class="pb10"><a href="add_reservation.php" class="a-btn a-btn-new">Přidat rezervaci</a></p>
<?php //}?>

<table class="data-table data">  
    <thead>
        <tr>
            <td>Vozidlo</td>
            <td>Rezervující</td>
            <td class="taRight">Od</td>
            <td class="taRight">Do</td>
            <td class="taRight">Datum vytvoření</td>
            <td></td>
        </tr>
    </thead>
    
    <?php 


        foreach($arr_data as $radek) {
            $id = $radek['id'];
            $vehicle_id = $radek['vehicle_id'];
            $auto = nacti_auto($vehicle_id);

    ?>
        
        <tr>
         <td><?php echo($auto['plate_number'] . " " . $auto['producer'] . " " . $auto ['model']);?></td>
         <td><?php echo(get_user_name($radek['user_id']));?></td>
         <td class="taRight"><?php echo(date_create($radek['since'])->format("j. n. Y"));?></td>
         <td class="taRight"><?php echo(date_create($radek['till'])->format("j. n. Y"));?></td>
         <td class="taRight"><?php echo(date_create($radek['create_date'])->format("j. n. Y"));?> </td>
        <td><a href="edit_reservation.php?id=<?php echo($id);?>">Upravit</a></td>
        
        </tr>
    <?php
        }
    ?>
</table>

<?php
include_once(__DIR__ . "/../includes/_footer.php");
?>
