<form method="POST" action="" class="data">

    <input type="hidden" name="id" value="<?php echo($id); ?>">

    <table class="simple-form-table">
    <tr>
            <td>Vozidlo:</td>
            <td>
            <select name="vehicle_id">
                <?php
                    foreach ($cars as $radek){
                        ?> 
                        <option value="<?php echo($radek['id']) ?>" <?php if($vehicle_id == $radek['id']) echo('selected')?> > <?php echo($radek['plate_number'] . " " . $radek['producer'] . " " . $radek['model'] . " (" . get_company_name_by_id($radek['company_id']) . ")") ?> </option>
                        <?php
                    }
                ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>Rezervující:</td>
            <td>
            <select name="user_id">
            <?php
                    foreach ($users as $radek){
                        ?> 
                        <option value="<?php echo($radek['id']) ?>" <?php if($user_id == $radek['id']) echo('selected')?> > <?php echo($radek['surname'] . " " . $radek['name'] . " (" . get_company_name_by_id($radek['company_id']) . ")") ?> </option>
                        <?php
                    }
                ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>Rezervace od:</td>
            <td>
            <input type="date" name="reservation_since" value="<?php echo($reservation_since);?>">
            </td>
        </tr>

        <tr>
            <td>Rezervace do:</td>
            <td>
            <input type="date" name="reservation_till" value="<?php echo($reservation_till);?>"></td>
        </tr>

    </table>

    <button type="submit" name="add_reservation" value="submit">Uložit</button>

</form>