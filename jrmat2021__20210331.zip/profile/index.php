<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "profile";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$data = db_execute("SELECT * FROM ". C_TABLE_REQUEST ." WHERE status='permitted' ORDER BY create_date ASC");
$arr_data = $data->fetchAll();
//print_r($arr_data);
include_once(__DIR__ . "/../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../includes/_msg.php");
?>

<div class="userdata">
<h2>Uživatel</h2>
<p>Jméno: <?php echo(get_SESSION('u_name'));?></p>
<p>Příjmení: <?php echo(get_SESSION('u_surname'));?></p>
<p>E-mail: <?php echo(db_getSimpleValue("SELECT email FROM ". C_TABLE_USERS ." WHERE id = ? ", [get_SESSION('u_id')]));?></p>
<p>Role: 
    <?php 
        if(get_SESSION('u_role') == 'superadmin') echo('Administrátor');
        if(get_SESSION('u_role') == 'spravce') echo('Správce');
        if(get_SESSION('u_role') == 'uzivatel') echo('Uživatel');
    ?>
</p>


<?php $firma = nacti_firmu();?>
<h2>Firma</h2>
<p>Název: <?php echo($firma['company_name']); ?></p>
<p>IČ: <?php echo($firma['ic']); ?></p>
<p>Kontaktní osoba: <?php echo($firma['first_name'] . " " . $firma['last_name'] ); ?></p>
<p>E-mail konktakní osoby: <?php echo($firma['email']); ?></p>

</div>


<?php
$PDO_statement = db_execute("SELECT * FROM " . C_TABLE_USERS . " WHERE id = ?", [get_SESSION("u_id")]);
$result = db_fetchrow($PDO_statement);
//print_r($result);



include_once(__DIR__ . "/../includes/_footer.php");
?>
