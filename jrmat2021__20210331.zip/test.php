<?php

// inicializace vseho potrebneho
require_once(__DIR__ . "/includes/page_init.php");

$result = odeslatEmail("rousekja@gmail.com", "test", "test odesilani emailu");
var_dump($result);

?>

