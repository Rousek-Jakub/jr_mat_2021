<?php

    session_start();

    require_once(__DIR__ . "/db.php");
    require_once(__DIR__ . "/functions.php");
    require_once(__DIR__ . "/UUID.php");
    require_once(__DIR__ . "/Validator.php");
    
    const C_TABLE_REQUEST = 't_request';
    const C_TABLE_USERS = 't_user';
    const C_TABLE_COMPANIES = 't_companies';
    const C_TABLE_VEHICLES = 't_cars';
    const C_TABLE_RESERVATIONS = 't_reservations';
    const C_TABLE_DATA = 't_data';
    
    const C_ROLE_ADMIN = 'superadmin';
    const C_ROLE_MANAGER = 'spravce';
    const C_ROLE_USER = 'uzivatel';

    $partition = "";
    $body_class = "";
    $section = "";
    $err = "";

    $PROTOCOL = "http";
    if ( SERVER("HTTPS") != "off" ) $PROTOCOL = "https";
    $HTTP_HOST = SERVER("HTTP_HOST");
    $BASE_URL = $PROTOCOL . "://" . $HTTP_HOST;
    define("C_BASE_URL", $BASE_URL);

    // nacist uzivatelske udaje do konstant pro snadnejsi pouzivani
    define("C_USER_ID", get_SESSION("u_id"));
    define("C_USER_ROLE", get_SESSION("u_role"));
    define("C_USER_COMPANY_ID", get_SESSION("u_company_id"));
    define("C_USER_IS_ADMIN", C_USER_ROLE === C_ROLE_ADMIN);
    define("C_USER_IS_MANAGER", C_USER_ROLE === C_ROLE_MANAGER);
    define("C_USER_IS_USER", C_USER_ROLE === C_ROLE_USER);

    define("C_BLACKLIST_DEFAULT_CHARACTERS", "<>;");
    define("C_WHITELIST_DEFAULT_CHARACTERS", "0123456789 ?!&@#-+.,\"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZěščřžýáíéóúůňťďĚŠČŘŽÝÁÍÉÓÚŮŇŤĎ");
    
    define("C_FUEL_TYPE_PETROL", "benzin");
    define("C_FUEL_TYPE_DIESEL", "diesel");
    define("C_FUEL_TYPE_LPG", "lpg");
    define("C_FUEL_TYPE_CNG", "cng");
    define("C_FUEL_TYPE_EE", "ee");

    define("C_SECTION_HOME", "home");
    define("C_SECTION_COMPANIES", "companies");
    define("C_SECTION_VEHICLES", "vehicles");
    define("C_SECTION_DATA", "data");
    define("C_SECTION_USERS", "users");
    define("C_SECTION_RESERVATIONS", "reservations");
    define("C_SECTION_EVENTS", "events");
    define("C_SECTION_ADMIN", "admin");
    define("C_SECTION_PROFILE", "profile");

    define("C_PART_REQ_NEW", "req_new");
    define("C_PART_REQ_PERMITTED", "req_permitted");
    define("C_PART_REQ_REJECTED", "req_rejected");


?>
