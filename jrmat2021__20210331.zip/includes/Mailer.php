<?php
	class Mailer {

		/* ============================================ */

		// constructor
		function Mailer() {

		}

		/* ============================================ */

		public static function Send($parFrom, $parTo, $parSubject, $parBody, $parAdditionalHeaders) {
			try {

				$smtp_auth = Konfigurace::Hodnota("smtp_auth");
				$smtp_host = Konfigurace::Hodnota("smtp_host");
				$smtp_port = Konfigurace::Hodnota("smtp_port");

				// by the value of the config key smtp_auth we decide wether to use authentication or not
				if ( $smtp_auth ) {
					require_once("Mail.php");

					$smtp_auth_username = Konfigurace::Hodnota("smtp_auth_username");
					$smtp_auth_password = Konfigurace::Hodnota("smtp_auth_password");

					$headers = array('From' => $parFrom, 'To' => $parTo, 'Subject' => $parSubject);
					$headers = array_merge($headers, $parAdditionalHeaders);
					$oSMTP = Mail::factory ('smtp', array ('host' => $smtp_host, 'port' => $smtp_port, 'auth' => true, 'username' => $smtp_auth_username, 'password' => $smtp_auth_password));
					$mail = $oSMTP->send($parTo, $headers, $parBody);

					if (PEAR::isError($mail)) {
						$result = -1;
						echo("<p>" . $mail->getMessage() . "</p>");
					} else {
						$result = 0;
					}
				} else {

					$headers = "";
					foreach ( $parAdditionalHeaders as $feKey => $feValue ) {
						$headers .= "$feKey: $feValue" . "\r\n";
					}

					ini_set("smtp", $smtp_host);

					$result = mail($parTo, $parSubject, $parBody, $headers, "-f " . $parFrom);
					if ( $result === false ) return -1;

				}


				return $result;
			} catch (Exception $e) {
				return -1;
			}
		}

	}
?>
