<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/styles/responsive.css" rel="stylesheet">
    <link href="/styles/css.css" rel="stylesheet">
    <title>Prehled</title>
</head>
<body class="<?php echo($body_class); ?>">
<header>
    <div class="content">
        <div class="logo"><img src="/img/logo_white.png" width="150" alt="CRAMS"></div>
        <nav class="head">
            <ul>

                <li class="<?php if ( $section == C_SECTION_HOME ) echo("active"); ?>"><a href="/index.php">Home</a></li>

				<?php if ( C_USER_IS_ADMIN ) { ?>
                    <li class="<?php if ( $section == C_SECTION_COMPANIES ) echo("active"); ?>"><a href="/admin/companies">Firmy</a></li>
				<?php } ?>

                <li class="<?php if ( $section == C_SECTION_VEHICLES ) echo("active"); ?>"><a href="/cars">Vozidla</a></li>

                <li class="<?php if ( $section == C_SECTION_DATA ) echo("active"); ?>"><a href="/data">Tankování</a></li>

				<?php if ( C_USER_IS_ADMIN || C_USER_IS_MANAGER ) { ?>
                    <li class="<?php if ( $section == C_SECTION_USERS ) echo("active"); ?>"><a href="/users">Uživatelé</a></li>
				<?php } ?>

                <li class="<?php if ( $section == C_SECTION_RESERVATIONS ) echo("active"); ?>"><a href="/reservations">Rezervace</a></li>

<!--                <li class="--><?php //if ( $section == C_SECTION_EVENTS ) echo("active"); ?><!--"><a href="/events">Události</a></li>-->

				<?php if ( C_USER_IS_ADMIN ) { ?>
                    <li class="<?php if ( $section == C_SECTION_ADMIN ) echo("active"); ?> dropbtn"><a href="/admin/requests/index.php">Admin</a></li>
                    <div class="xdropdown nav-level-2">
                        <div class="xdropdown-content">
                            <li class="<?php if ( $partition == C_PART_REQ_NEW ) echo("active"); ?>"><a href="/admin/requests/">Žádosti nové</a></li>
                            <li class="<?php if ( $partition == C_PART_REQ_PERMITTED ) echo("active"); ?>"><a href="/admin/requests/permited.php">Žádosti schválené</a></li>
                            <li class="<?php if ( $partition == C_PART_REQ_REJECTED ) echo("active"); ?>"><a href="/admin/requests/rejected.php">Žádosti zamítnuté</a></li>
                        </div>
                    </div>
				<?php } ?>

                <li class="<?php if ( $section == "profile" ) echo("active"); ?>"><a href="/profile">Profil</a></li>

                <li><a href="/logout.php">Odhlásit</a></li>
            </ul>
        </nav>
    </div>
</header>
<main>
