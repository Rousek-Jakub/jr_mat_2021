<?php
class Validator {

	public static function ValidujWhitelist($parInput, $parWhitelistCharacters = null) {
		
		$list = C_WHITELIST_DEFAULT_CHARACTERS;
		if ( !is_null($parWhitelistCharacters) ) $list = $parWhitelistCharacters;

		$arr_input = str_split($parInput);
		foreach ( $arr_input as $feZnak ) {
			if ( mb_strpos($list, $feZnak) === false ) return false;
		}

		return true;
		
	}

	public static function ValidujBlacklist($parInput, $parBlacklistCharacters = null) {
		
		$list = C_BLACKLIST_DEFAULT_CHARACTERS;
		if ( !is_null($parBlacklistCharacters) ) $list = $parBlacklistCharacters;

		$arr_input = str_split($parInput);
		foreach ( $arr_input as $feZnak ) {
			if ( mb_strpos($list, $feZnak) !== false ) return false;
		}

		return true;
		
	}

	public static function ValidujEmail($parEmail) {
		return preg_match("/^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[A-Za-z]{2,5}$/", $parEmail);
	}

	public static function ValidujURL($parURL, $parVcetneProtokolu = false) {
		return preg_match('|^[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $parURL) > 0 ;
	}

	public static function ValidujDatum($date){
		return date_parse($date);
	}

	public static function ValidujCislo($parHodnota, $parDelka = 0, $parMaxDelka = 0) {
		try {
			
			//if ( $parDelka == 0 && !is_numeric($parHodnota) ) return false;

			// nejdrive samotny retezec, ten nesmi obsahovat zadny neciselny znak
			$arr_chars = str_split($parHodnota);
			foreach ( $arr_chars as $feItem ) if ( !is_numeric($feItem) ) return false;

			if ( $parDelka > 0 && $parMaxDelka == 0 ) return preg_match("/^[0-9]{" . strval($parDelka)."}$/", $parHodnota) > 0; 
			if ( $parDelka > 0 && $parMaxDelka > 0 ) return preg_match("/^[0-9]{" . strval($parDelka)."," . strval($parMaxDelka)."}$/", $parHodnota) > 0;

			return true;

		} catch ( Exception $ex ) {
			Logger::Exception($ex);
			return false;
		}

	}

}
?>
