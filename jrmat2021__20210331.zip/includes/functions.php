<?php 
// funkce posle na klienta hlavicku s poradavkem na presmerovani na zadanou url
function redirect($parURL) {
    header("HTTP/1.1 200 OK");
    header("Location: $parURL");
    header("Connection: close");
    exit;
  }

function GenerujEnglishLikeString($parDelka = 6, $parAF = false) {

    $r = "";
    for ( $i = 0; $i < $parDelka; $i++ )
      if ( !$parAF ) $r .= chr(rand(0, 25) + ord('a'));
      else $r .= chr(rand(0, 5) + ord('a'));
    return $r;
  }

function validateEmail($email){
    //$regex = '/^(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){255,})(?!(?:(?:\x22?\x5C[\x00-\x7E]\x22?)|(?:\x22?[^\x5C\x22]\x22?)){65,}@)(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22))(?:\.(?:(?:[\x21\x23-\x27\x2A\x2B\x2D\x2F-\x39\x3D\x3F\x5E-\x7E]+)|(?:\x22(?:[\x01-\x08\x0B\x0C\x0E-\x1F\x21\x23-\x5B\x5D-\x7F]|(?:\x5C[\x00-\x7F]))*\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-[a-z0-9]+)*\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-[a-z0-9]+)*)|(?:\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\]))$/iD';
}

function existsRequestByIC($ic){

}

// funkce enkoduje nebezpecne znaky
function db_escape($parString2Escape) {

    if ( is_null($parString2Escape) ) return "null";

    if ( is_numeric($parString2Escape) || is_bool($parString2Escape) ) {
      return $parString2Escape;
    } else if ( is_string($parString2Escape) ) {
      return addslashes($parString2Escape);
    } else if ($parString2Escape) {
      print_r($parString2Escape);
      throw new Exception('Invalid data type.');
    }

  } 
//nacte data z dotazu a vrátí 
function db_execute($sqlQuery, $parameters = null){
   try{ 
    //spustit dotaz 
    global $pdo;
    $pdoStatement = $pdo->prepare($sqlQuery);
    if($pdoStatement === false){
        //logovat problém
        
        //vrátit false
        return false;
    }

    //nacist data
    $result = $pdoStatement->execute($parameters);
    if($result === false){
        return false;
        
    }
    return $pdoStatement;
  
   } catch(Exception $e){
        // echo 'Caught exception: ',  $e->getMessage(), "\n";
        var_dump($e);
        return false;
   }
}



//vraci 1 radek 1 sloupec (první bunku)
function db_getSimpleValue($sqlQuery, $parameters = null){
    try {
        $result = db_execute($sqlQuery, $parameters);
        if($result === false){
            return false;
        }
        //načtení dat do pole
        $arr_data = $result->fetch(PDO::FETCH_BOTH);
        if ($arr_data === false) {
            return false;
        }

        if(is_array($arr_data)){
            if(count($arr_data)>0){
                if(isset($arr_data[0])){
                  return $arr_data[0];
                }

            }
        } 
         return null;
       

    } catch ( Throwable $th) {
        var_dump($th);
        //throw $th;
    }
}

function is_new_request($id){
  try{
    $pocet = db_getSimpleValue("SELECT count(id) FROM ". C_TABLE_REQUEST ." WHERE id='$id' AND status='new'");
    if($pocet === false || $pocet === null){
      return false;
    }
    if((int)$pocet >= 1){
      return true;
    } else { return false;}
  } catch ( Throwable $th) {
    var_dump($th);
    //throw $th;
}
}
function SERVER($param, $vychozi_hodnota = null){
  try{
    if(isset($_SERVER[$param])){
      return $_SERVER[$param];
    }
    else{
      return $vychozi_hodnota;
    }
  } catch ( Throwable $th) {
      var_dump($th);
      //throw $th;
  }
}

function GET($param, $vychozi_hodnota = null){
  try{
    if(isset($_GET[$param])){
      return $_GET[$param];
    }
    else{
      return $vychozi_hodnota;
    }
  } catch ( Throwable $th) {
      var_dump($th);
      //throw $th;
  }
}

function POST($param, $vychozi_hodnota = null){
  try{
    if(isset($_POST[$param])){
      return $_POST[$param];
    }
    else{
      return $vychozi_hodnota;
    }
  } catch ( Throwable $th) {
      var_dump($th);
      //throw $th;
  }
}

function is_existing_ic($param){
  $q = "SELECT count(ic) FROM " . C_TABLE_REQUEST . " WHERE ic = ?";
  $result = db_getSimpleValue($q, [$param]);
  if ( (int)$result === 0 ) {
    return false;
} else {
  return true;
}

}

function is_existing_email($param){
  $q = "SELECT count(email) FROM " . C_TABLE_REQUEST . " WHERE email = ?";
  $result = db_getSimpleValue($q, [$param]);
  if ( (int)$result === 0 ) {
    return false;
} else {
  return true;
}
} 

function is_existing_company($param){
  $q = "SELECT count(id) FROM " . C_TABLE_COMPANIES . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$param]);
  if ( (int)$result === 0 ) {
    return false;
} else {
  return true;
}
}


function zapis_registraci_do_databaze($ic, $email, $jmeno, $prijmeni, $nazev){
  $uuid = UUID::v5();

  $q = "INSERT INTO " . C_TABLE_REQUEST ." (id, company_name, ic, name, surname, email, status) values (
       '$uuid', 
       '" . db_escape($nazev) . "', 
       '" . db_escape($ic) . "', 
       '" . db_escape($jmeno) . "', 
       '" . db_escape($prijmeni) . "', 
       '" . db_escape($email) . "', 
       'new'
  );";

  // zapis
  $result = db_execute($q);
  if($result === false){
    return false;
  } else {
    return $uuid;
  }
}

function is_valid_login_data($email, $heslo){
 $q = "SELECT count(email) FROM " . C_TABLE_USERS . " WHERE email = ? AND password = ?"; 

 $result = db_getSimpleValue($q, [$email, sha1($heslo)]);
 if($result === false || is_null($result)){
   return false;
 } else {
  if((int)$result === 1){
    //zaznam nalezen, validni data
    return true;
  } else if((int)$result === 0){
    //zaznam nebyl nalezen data nejsou validni
    return false;
  } else {
      //chyba v integritě dat
      return true;
  }
  return false;
 }
}
function log_me($email){
  $q ="SELECT * FROM " . C_TABLE_USERS . " WHERE email = ?";
  $result = db_execute($q, [$email]);
  if($result === false){
    //nepovedlo se
    return false;
  } else {
    //nacist data do pole
    $user_data = $result->fetch(PDO::FETCH_ASSOC);
      set_SESSION("u_id", $user_data['id']);
      set_SESSION("u_name", $user_data['name']);
      set_SESSION("u_surname", $user_data['surname']);
      set_SESSION("u_role", $user_data['role']);
      set_SESSION("u_company_id", $user_data['company_id']);
     return 0;
  }
}

function set_SESSION($name, $value){
  try{
    //zapis do session
    $_SESSION [$name] = $value;
    return 0;


  } catch ( Throwable $th) {
      var_dump($th);
      //throw $th;
  }
}


function get_SESSION($param, $vychozi_hodnota = ""){
  try{
    if(isset($_SESSION[$param])){
      return $_SESSION[$param];
    }
    else{
      return $vychozi_hodnota;
    }
  } catch ( Throwable $th) {
    var_dump($th);
      //throw $th;
  }
}

function require_user_login(){
  if(get_SESSION("u_id") == ""){
    //neni prihlasen
    redirect("/login.php");
  }

}

function nactiZadost($id){
  try{
    $data = db_execute('SELECT * FROM ' . C_TABLE_REQUEST . ' WHERE id = ?', [$id]);
    if($data === false){
      return false;
    } else {
      //nacist data do pole
      $data = $data->fetch(PDO::FETCH_ASSOC);
      return $data;
    }
  } catch ( Throwable $th) {
    var_dump($th);

  }
}

function zamitnoutZadost($id, $predmet, $body) {
  try {

    // nebyla uz zadost vyrizena???
    $result = jeZadostVyrizena($id);
    if ($result === false ) return false;
    if ( $result === 1 ) return false;

    // nacist data zadosti
    $data = nactiZadost($id); if ($data === false ) return false;

    $email = $data["email"];

    // odeslat email
    $result = odeslatEmail($email, $predmet, $body);
    if ( $result === false ) return false;

    // oznacit zadost jako vyrizenou, schvalenou
    $result = db_execute("UPDATE " . C_TABLE_REQUEST . " SET status = 'rejected', process_date = now() WHERE id = ?", [$id]);
    if ( $result === false ) return false;

    return 0;

  } catch ( Throwable $th) {
    var_dump($th);

  }
}


function schvalitZadost($id, $predmet, $body, $password) {
  try {

    // nebyla uz zadost vyrizena???
    $result = jeZadostVyrizena($id);
    if ($result === false ) return false;
    if ( $result === 1 ) return false;

    // nacist data zadosti
    $data = nactiZadost($id); if ($data === false ) return false;

    $email = $data["email"];

    //vytvořit firmu
    $result = vytvorFirmu($data['ic'], $data['company_name'], $data['name'], $data['surname'], $data['email']);
    if ($result === false ) return false;
    $company_id = $result;

    //vytvorit uzivatele s danym heslem
    $result = vytvorUzivateleDleZadosti($id, $password, $company_id);
    if ($result === false ) return false;

    //v $result je id noveho uzivatele
    $user_id = $result;

    // odeslat email
    $result = odeslatEmail($email, $predmet, $body);
    if ( $result === false ) return false;

    // oznacit zadost jako vyrizenou, schvalenou
    $result = db_execute("UPDATE " . C_TABLE_REQUEST . " SET status = 'permitted', process_date = now() WHERE id = ?", [$id]);
    if ( $result === false ) return false;

    return $user_id;

  } catch ( Throwable $th) {
    var_dump($th);

  }
}


function vytvorUzivateleDleZadosti($id, $password, $company_id){
  
  $data = nactiZadost($id); if ($data === false ) return false;

  $user_id = UUID::v5();
  $result = db_execute('INSERT INTO ' . C_TABLE_USERS . 
  ' (id, email, password, name, surname, required_password_change, create_date, role, company_id) 
  VALUES (?, ?, ?, ?, ?, 1, now(), \'spravce\', ?)' , [$user_id, $data['email'], sha1($password), $data['name'], $data['surname'], $company_id] );
if($result === false ) return false; 
return $user_id;
}

function odeslatEmail($adresa, $predmet, $body){
 
  require_once(__DIR__ . "/PHPMailer/PHPMailerAutoload.php");

  $smtp_host = "smtp.gmail.com";
  $smtp_port = "587";
  $smtp_auth_username = "noreply.crams@gmail.com";
  $smtp_auth_password = "Hrochhroch123";

  $mail = new PHPMailer();
  $mail->isSMTP();
  $mail->SMTPDebug = 0;
  $mail->Host = $smtp_host;
  $mail->Port = $smtp_port;
  $mail->SMTPSecure = "tls";
  $mail->SMTPAuth = true;
  $mail->Username = $smtp_auth_username;
  $mail->Password = $smtp_auth_password;
  $mail->setFrom($smtp_auth_username, "CRAMS");
  $mail->Timeout = 10;
  $mail->SMTPOptions = array(
    'ssl' => array(
      'verify_peer' => false,
      'verify_peer_name' => false,
      'allow_self_signed' => true
    )
  );

  $mail->ConfirmReadingTo = $smtp_auth_username;
  $mail->isHTML(false);
  $mail->Body = $body;
  $mail->Subject = $predmet;

  $result = $mail->addAddress($adresa, $adresa);
  if ( $result === false ) {
    $err = "Chyba pri addAddress: " . $mail->ErrorInfo;
  } else {
    //send the message, check for errors
    if ( $mail->send() === false ) {
      $err = "Pri odesilani e-mailu na adresu " . $adresa . " doslo k chybe: " . $mail->ErrorInfo;
    } else return 0;
  }

  return $err;
 
}

function jeZadostVyrizena($id) {

    $result = db_getSimpleValue("select count(id) from " . C_TABLE_REQUEST . " where id = ? and process_date is not null;", [$id]);
    if ( $result === false ) return false;
    // > 0 = je vyrizena
    if ( (int)$result > 0 ) return 1;
    return 0;

}

function vytvorFirmu($ic, $company_name, $first_name, $surname, $email){
  //kontrola existence firmy s ic
  $q = "select count(id) from " . C_TABLE_COMPANIES . " where ic = ?;";
  $result = db_getSimpleValue($q, [$ic]);
  if ( $result === false ) return false;
  if ( (int)$result > 0 ) return false;

  // generovani uuid
  $id = UUID::v5();

  //zapis
  $result = db_execute("INSERT INTO " . C_TABLE_COMPANIES . " (id, company_name, first_name, last_name, ic, email)
   VALUES 
   (?,?,?,?,?,?)", [$id, $company_name, $first_name, $surname, $ic, $email]);
  if($result === false ) return false; 
  return $id;
}

function check_user_role($par_role){
   $role = get_SESSION("u_role");
   if($par_role == $role){
     return true;
   } 
   return false;
}



function require_user_role($par_role){
   if(check_user_role($par_role) == true){
      return true;
    } else {
      redirect('/access_denied.php');
    }
}

function nacti_firmu(){
  $id = db_getSimpleValue("SELECT company_id FROM " . C_TABLE_USERS . " WHERE id = ?", [get_SESSION("u_id")]);  

  $firma = db_execute("SELECT * FROM " . C_TABLE_COMPANIES . " WHERE id = ?", [$id]);
  $result = db_fetchrow($firma);
  if($result == false){
    return false;
  }
  return $result;
}

function get_company_name_by_id($id){
  $q = "SELECT company_name FROM " . C_TABLE_COMPANIES . " WHERE id = ?";
  return db_getSimpleValue($q, [$id]);
}

function get_user($id){
  $result = db_execute("SELECT * FROM " . C_TABLE_USERS . " where id = ? ORDER BY surname ASC, name ASC", [$id]);
  if($result === false){
    return false;
  }
  return db_fetch_all($result);
}

function get_user_name($id){
  $name = db_getSimpleValue("SELECT concat(name, ' ', surname) FROM " . C_TABLE_USERS . " WHERE id = ?", [$id]);  
  if($name == false){
    return false;
  }
  return $name;
}


function is_existing_car($id){
  $q = "SELECT count(id) FROM " . C_TABLE_VEHICLES . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$id]);
  if ( (int)$result === 0 || $result === false ) return false;
  return true;
} 

function is_existing_car_plate_number($plate_number){
  $q = "SELECT count(id) FROM " . C_TABLE_VEHICLES . " WHERE plate_number = ?";
  $result = db_getSimpleValue($q, [$plate_number]);
  if ( (int)$result === 0 || $result === false ) return false;
  return true;
} 

function nacti_auto($id){

  if ( is_existing_car($id) === false ) return false;

  $q = "SELECT * FROM " . C_TABLE_VEHICLES . " WHERE id = ?;";
  $result = db_execute($q, [$id]);
  if ( $result === false ) return false;

  $result = db_fetchrow($result);
  if ( $result === false ) return false;

  return $result;
}

function db_fetchrow($PDO_statement, $fetch_type = PDO::FETCH_ASSOC){
  $result = $PDO_statement->fetch($fetch_type);
  if($result == false){
    return false;
  } 
  return $result;
}

/**
 * @param $parTable - nazev tabulky
 * @param $parColumn - nazev sloupce, jehoz hodnotu chces nacist
 * @param $parKeyName - nazev klice
 * @param $parKeyValue - hodnota klice
 * @return false
 */
function db_getColumnValue($parTable, $parColumn, $parKeyName, $parKeyValue) {
  $q = "select $parColumn from $parTable where $parKeyName = ?";
  $result = db_getSimpleValue($q, [$parKeyValue]);
  if ( $result === false ) return false;
  return $result;
}

function db_fetch_all($PDO_statement,  $fetch_type = PDO::FETCH_ASSOC){
  
  if ( $PDO_statement->rowCount() == 0 ) return array();

  $result = $PDO_statement->fetchAll($fetch_type);
  if($result == false){
    return false;
  } 
  return $result;

}

function db_fetch_all_simple($PDO_statement){
  $result = $PDO_statement->fetchAll(PDO::FETCH_NUM);
  if($result == false) {
    return false;
  }
  $arr_out = array();
  foreach ( $result as $feItem ) {
    $arr_out[] = $feItem[0];
  }
  return $arr_out;

}

  function nacti_firmy(){
  $companies = "SELECT * FROM " . C_TABLE_COMPANIES . " ORDER BY company_name ASC";
  $result = db_execute($companies);

  if($result === false){
    return false;
  }

  return db_fetch_all($result);
  
}

function is_valid_user_id($id){
  $q = "SELECT id FROM " . C_TABLE_USERS . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$id]);

  if ( $id == $result ) return true;
  return false;

}

function is_company_belong_to_user($company_id, $user_id){
  $q = "SELECT count(company_id) FROM " . C_TABLE_USERS . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$user_id]);
  if ( $company_id == $result ) return true;
  return false;
}

function is_user_belong_to_manager($user_id, $manager_id){
  
  // nacteni id spolecnosti managenra
  $q = "SELECT count(company_id) FROM " . C_TABLE_USERS . " WHERE id = ?";
  $manager_company_id = db_getSimpleValue($q, [$manager_id]);

  // nacteni id spolecnosti uzivatele
  $q = "SELECT count(company_id) FROM " . C_TABLE_USERS . " WHERE id = ?";
  $user_company_id = db_getSimpleValue($q, [$user_id]);

  // porovnani id spolecnosti uzivatele a managera
  if ( $manager_company_id === $user_company_id ) return true;
  return false;

}

function is_car_belong_to_company(){

}


//vrátí seznam id aut patřících společnosti dle id společnosti
function get_company_cars_id($id){
  $q = "SELECT id FROM " . C_TABLE_VEHICLES . " WHERE company_id = ?";
  $result = db_execute($q, [$id]);
  if($result === false){
    return false;
  }
    return db_fetch_all_simple($result);
}

function get_user_reserved_cars($user_id){
  $q = "SELECT * FROM " . C_TABLE_VEHICLES . " WHERE id IN ( SELECT vehicle_id FROM " . C_TABLE_RESERVATIONS . " WHERE user_id = ? ) ORDER BY producer, model ASC";
  $result = db_execute($q, [$user_id]);
  if($result === false){
    return false;
  }
    return db_fetch_all($result);
}

// vraci vsechna auta
function get_all_cars(){
  $result = db_execute("SELECT * FROM " . C_TABLE_VEHICLES . " ORDER BY plate_number ASC");
  if($result === false){
    return false;
  }
  return db_fetch_all($result);
}
// vraci vsechny uzivatele
function get_all_users(){
  $result = db_execute("SELECT * FROM " . C_TABLE_USERS . " ORDER BY surname ASC, name ASC");
  if($result === false){
    return false;
  }
  return db_fetch_all($result);
}


// vraci vsechna auta patrici firme
function get_company_cars($company_id){
  $result = db_execute("SELECT * FROM " . C_TABLE_VEHICLES . " where company_id = ? ORDER BY plate_number ASC", [$company_id]);
  if($result === false){
    return false;
  }
  return db_fetch_all($result);
}
function get_company_users($company_id){
  $result = db_execute("SELECT * FROM " . C_TABLE_USERS . " where company_id = ? ORDER BY surname ASC, name ASC", [$company_id]);
  if($result === false){
    return false;
  }
  return db_fetch_all($result);
}

function get_car_plate_number($id){
  $q = "SELECT plate_number FROM " . C_TABLE_VEHICLES . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$id]);
  if($result === false){
    return false;
  }

  return $result;

}

function is_existing_reservation($id){
  $q = "SELECT id FROM " . C_TABLE_RESERVATIONS . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$id]);

  if($result === false) return false;
  if(is_null($result)){
    return false;
  } else return true;
  
}

function is_existing_data($id){
  $q = "SELECT id FROM " . C_TABLE_DATA . " WHERE id = ?";
  $result = db_getSimpleValue($q, [$id]);

  if($result === false) return false;
  if(is_null($result)){
    return false;
  } else return true;
}

function belong_to_same_company($user_id, $vehicle_id){
  $user_company_id = db_getSimpleValue("SELECT company_id FROM " . C_TABLE_USERS . " WHERE id = ?", [$user_id]);
  $vehicle_company_id = db_getSimpleValue("SELECT company_id FROM " . C_TABLE_VEHICLES . " WHERE id = ?", [$vehicle_id]);

  if($user_company_id != $vehicle_company_id) return false;
  return true;

}

function nacti_rezervaci($id){
  $q = "SELECT * FROM " . C_TABLE_RESERVATIONS . " WHERE id = ?";
  $result = db_execute($q, [$id]);
  if($result === false) return false;
  return db_fetchrow($result);
}

function nacti_data($id){
  $q = "SELECT * FROM " . C_TABLE_DATA . " WHERE id = ?";
  $result = db_execute($q, [$id]);
  if($result === false) return false;
  return db_fetchrow($result);
}

function nacti_uzivatele($id){
  $users = "SELECT * FROM " . C_TABLE_USERS . " WHERE id = ? ORDER BY id ASC";
  $result = db_execute($users, [$id]);

  if($result === false){
    return false;
  }

  return db_fetchrow($result);
  
}

function get_date_collisions($reservation_since, $reservation_till, $vehicle_id, $existing_reservation_id = ""){

  //nacist rezervace k danemu vozidlu
    //$q = "SELECT * FROM " . C_TABLE_RESERVATIONS . " WHERE (? <= till OR ? >= since) AND vehicle_id = ? ";
    $q = "SELECT * FROM " . C_TABLE_RESERVATIONS . " WHERE (((? BETWEEN since AND till) OR (? BETWEEN since AND till)) OR ((since BETWEEN ? AND ?) OR (till BETWEEN ? AND ?))) AND vehicle_id = ? ";
    $arr_params = [$reservation_since, $reservation_till, $reservation_since, $reservation_till, $reservation_since, $reservation_till, $vehicle_id];

    if($existing_reservation_id != ""){
      $q .= " AND id != ?";
      $arr_params[] = $existing_reservation_id;
    }

    //echo($q); print_r($arr_params); die;

    $result = db_execute($q, $arr_params);
    if ( $result === false ) {
      //die("XXX");
      return false;
    }

    $out = db_fetch_all($result);
    if ( $out === false ) {
      return false;
    }
    return $out;

}