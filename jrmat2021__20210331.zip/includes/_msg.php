<?php

$msg_success = GET("msg_success");
$msg_error = GET("msg_error", $err);

if ( $msg_success != "" ) { ?><p class="msg msg_success"><?php echo($msg_success); ?></p> <?php }
if ( $msg_error != "" ) { ?><p class="msg msg_error"><?php echo($msg_error); ?></p> <?php }


