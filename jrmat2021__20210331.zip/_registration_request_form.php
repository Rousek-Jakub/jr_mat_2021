
<div id="login_window">
    <h1>Žádost o registraci</h1>

    <?php include(__DIR__ . "/includes/_msg.php"); ?>
    
    <form action="registration_request.php" method="POST">

    <p class="input_text">Název společnosti:</p>
        <input type="text" name="company_name" placeholder="Název firmy" class="login-input" value="<?php echo($nazev) ?>">
    <p class="input_text">IČ.:</p>
        <input type="text" name="ic" placeholder="IČ" class="login-input" value="<?php echo($ic) ?>">
    <p class="input_text">Jméno kontaktní osoby:</p>
        <input type="text" name="first_name" placeholder="Jméno kontaktní osoby" class="login-input" value="<?php echo($jmeno) ?>">
    <p class="input_text">Příjmení kontaktní osoby</p>
        <input type="text" name="surname" placeholder="Příjmení kontaktní osoby" class="login-input" value="<?php echo($prijmeni) ?>">
    <p class="input_text">E-mail:</p>
        <input type="email" name="email" placeholder="Email" class="login-input" value="<?php echo($email       ) ?>">
        <button id="submit-button" name="submit_btn" type="submit" value="Register">Zažádat</button>
    </form>
    <p class="pb10 pl10">
        Všechna pole jsou povinná.
        <br>
        Po odeslání žádosti obdržíte e-mail s instrukcemi.
    </p>
    <p class="pl10">Již máte účet? <a href="/login.php">Přihlášte se!</a></p>
</div>
