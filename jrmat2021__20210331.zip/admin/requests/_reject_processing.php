<?php
$subject = "Zamítnutá  žádost o registraci do systému CRAMS";
$body = file_get_contents(__DIR__ . "/../../includes/reject_text.txt");

$submit_btn = POST("submit_btn");

if ( $submit_btn == "reject" ) {

    // zpracovávám data z formuláře
    // nacist data z formu

    $id = POST("id");
    $body = POST('body');
    $subject = POST('subject');

    $data = nactiZadost($id);


    // kontrola

    // kontrola na stav zadosti

    // kontrola na existenci uzivatele s emailem

    // zpracovat je (odeslat email, oznacit zadost za vyrizenou)
    $result = zamitnoutZadost($id, $subject, $body);

    // pokud neni chyba redirekt na stranku s hlasenim o vysledku
    if($result !== false){
        $url = "/admin/requests/?msg_success=" . urlencode("Žádost byla zamítnuta");
        redirect($url);
    }
    
    // pokud je chyba zobrazit error a znovu form s udaji jak byly odeslany
    $err = "Chyba při zpracování požadavku";
    
} else {

    // zpracovávám data pro zobrazení formuláře

    $id = GET('id');
    if($id === null){
        echo("Chybí identifikace požadavku");
    } else {
        $platnost = is_new_request($id);
		if ( $platnost === false ) $err = "Požadavek je neplatný";
        else {
    
            $data = nactiZadost($id);

            //nahrazeni placeholderů v dokumentu

            $body = str_replace("<!--(email)-->", $data['email'], $body);
            $body = str_replace("<!--(jmeno)-->", $data['name'], $body);
            $body = str_replace("<!--(prijmeni)-->", $data['surname'], $body);

        }

    }

}


?>