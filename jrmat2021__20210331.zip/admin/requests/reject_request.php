<?php
require_once(__DIR__ . "/../../includes/page_init.php");

require_user_login();
require_user_role(C_ROLE_ADMIN);

$section = C_SECTION_ADMIN;
$partition = C_PART_REQ_NEW;

include_once __DIR__ . "/_reject_processing.php";
include_once __DIR__ . "/../../includes/_header.php";

?>

<h1>Zamítnutí žádosti</h1>

<?php

include_once __DIR__ . "/_reject_form.php";
include_once __DIR__ . "/../../includes/_footer.php";

?>