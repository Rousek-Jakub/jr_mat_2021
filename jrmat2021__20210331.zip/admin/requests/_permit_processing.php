<?php
$subject = "Schválená žádost o registraci do systému CRAMS";
$body = file_get_contents(__DIR__ . "/../../includes/permit_text.txt");
$password = "";


$submit_btn = POST("submit_btn");

if ( $submit_btn == "permit" ) {

    // zpracovávám data z formuláře
    // nacist data z formu

    $id = POST("id");
    $body = POST('body');
    $subject = POST('subject');
    $password = POST('password');

    $data = nactiZadost($id);


    // kontrola

//    $data = nactiZadost($id);
//    $email = $data["email"];

    // kontrola na stav zadosti

    // kontrola na existenci uzivatele s emailem


    // zpracovat je (odeslat email, oznacit zadost za vyrizenou)
    $result = schvalitZadost($id, $subject, $body, $password);

    // pokud neni chyba redirekt na stranku s hlasenim o vysledku
    if($result !== false){
        $url = "/admin/requests/?msg_success=" . urlencode("Žádost byla schválena, byl vytvořen uživatel id = $result");
        redirect($url);
    }
    
    // pokud je chyba zobrazit error a znovu form s udaji jak byly odeslany
    $err = "Chyba při zpracování požadavku";
    
} else {

    // zpracovávám data pro zobrazení formuláře

    $id = GET('id');
    if($id === null){
        echo("Chybí identifikace požadavku");
    } else {
        $platnost = is_new_request($id);
        if ( $platnost === false ) $err = "Požadavek je neplatný";
        else {
    
            $data = nactiZadost($id);

    
            //generuj heslo uživateli
            $password = GenerujEnglishLikeString(12);

            //nahrazeni placeholderů v dokumentu

            $body = str_replace("<!--(login)-->", $data['email'], $body);
            $body = str_replace("<!--(jmeno)-->", $data['name'], $body);
            $body = str_replace("<!--(password)-->", $password, $body);
            $body = str_replace("<!--(prijmeni)-->", $data['surname'], $body);
            // zadost je overena a je mozne ji zpracovat
            // 1) vytvorit ucet (vygenerovat mu heslo a donutit ho pri prvnim prihlaseni zmenit heslo )
            // 2) poslat mu email s informacema o uctu ( email, heslo, informace o nutnosti zmeny hesla atd... )
            // 3) uprava dat samotne zadosti (zmena statusu a zapis datumu kdy se to zmenilo)
            // pokud je to vsechno cajk, das adminovi informaci 
            
        }

    }

}


?>