 
<?php 

if($err != "") {
    echo("<p class=\"taCenter msg msg_error p20\">" . $err . "</p>");
}

?>
 
    <form method="POST">

        <input type="hidden" name="id" value="<?php echo($id)?>">
        <input type="hidden" name="password" value="<?php echo($password)?>">

        <table class="simple-form-table">
        <tr>
            <td>Společnost: </td>
            <td><?php echo($data['company_name']);  ?></td>
            </tr>
            <tr>
            <td>IČ: </td>
            <td><?php echo($data['ic']);  ?></td>
            </tr>
            <tr>
            <td>Jméno: </td>
            <td><?php echo($data['surname'] . " " . $data['name']);  ?></td>
            </tr>
            <tr>
            <td>E-mail: </td>
            <td><?php echo($data['email']);  ?></td>
            </tr>

            <tr>
            <td>Předmět: </td>
            <td><input type="text" name="subject" placeholder="subject" value="<?php echo($subject)?>"></td>
            </tr>

            <tr>
            <td class="vaTop">Obsah: </td>
            <td><textarea name="body" rows="10" cols="50"><?php echo($body);?></textarea></td>
            </tr>

        </table>

        <button type="submit" name="submit_btn" value="permit">Schválit</button>
    </form>
