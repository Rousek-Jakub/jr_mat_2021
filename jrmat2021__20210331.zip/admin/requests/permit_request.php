<?php
require_once(__DIR__ . "/../../includes/page_init.php");  


require_once(__DIR__ . "/../../includes/page_init.php");  
$id = $_GET['id'];

//echo($id);

// test prihlaseni spravce a overeni jeho prav
// pokud neni prihlasen tak redirekt na prihlaseni
// pokud nema prava tak ho nejak vyfakovat

include_once __DIR__ . "/_permit_processing.php";
include_once __DIR__ . "/../../includes/_header.php";

?>

	<h1>Schválení žádosti</h1>

<?php

include_once __DIR__ . "/_permit_form.php";
include_once __DIR__ . "/../../includes/_footer.php";

?>