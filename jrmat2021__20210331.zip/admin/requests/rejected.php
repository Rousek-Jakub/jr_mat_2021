<?php
require_once(__DIR__ . "/../../includes/page_init.php");
//overeni typu uzivatele a jeho prava

require_user_login();
require_user_role(C_ROLE_ADMIN);

$section = C_SECTION_ADMIN;
$partition = C_PART_REQ_REJECTED;

//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$data = db_execute("SELECT * FROM ". C_TABLE_REQUEST ." WHERE status='rejected' ORDER BY create_date ASC");
$arr_data = $data->fetchAll();
//print_r($arr_data);
include_once(__DIR__ . "/../../includes/_header.php");

include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../../includes/_msg.php");
?>

<h1>Zamítnuté žádosti</h1>

<table class="data-table">
    <thead>
        <tr>
            <td>Název Firmy</td>
            <td>IČ</td>
            <td>Jméno</td>
            <td>Příjmení</td>
            <td>Email</td>
            <td class="taRight">Datum vytvoření žádosti</td>
            <td></td>
            <td></td>
        </tr>
    </thead>
    
    <?php 

        foreach($arr_data as $radek) {
    ?>
        <tr>
         <td><?php echo($radek["company_name"]);?></td>
         <td><?php echo($radek["ic"]);?></td>
         <td><?php echo($radek["name"]);?></td>
         <td><?php echo($radek["surname"]);?></td>
         <td><?php echo($radek["email"]);?></td>
         <td class="taRight"><?php echo(date_create($radek["create_date"])->format("j. n. Y H:i"));?></td>
         <td><a href="permit_request.php?id=<?php echo($radek['id']);?>">Schválit</a></td>
         <td><a href="reject_request.php?id=<?php echo($radek['id']);?>">Zamítnout</a></td>
        </tr>
    <?php
        }
    ?>
</table>

<?php
include_once(__DIR__ . "/../../includes/_footer.php");
?>
