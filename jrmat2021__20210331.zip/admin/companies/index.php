<?php
require_once(__DIR__ . "/../../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "companies";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$data = db_execute("SELECT * FROM ". C_TABLE_COMPANIES ." ORDER BY company_name ASC");
$arr_data = $data->fetchAll();
//print_r($arr_data);
include_once(__DIR__ . "/../../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../../includes/_msg.php");
?>

<table class="data-table data">  
    <thead>
        <tr>
            <td>Název Firmy</td>
            <td>IČ</td>
            <td>Jméno</td>
            <td>Příjmení</td>
            <td>Email</td>
        </tr>
    </thead>
    
    <?php 

        foreach($arr_data as $radek) {
    ?>
        <tr>
         <td><?php echo($radek["company_name"]);?></td>
         <td><?php echo($radek["ic"]);?></td>
         <td><?php echo($radek["first_name"]);?></td>
         <td><?php echo($radek["last_name"]);?></td>
         <td><?php echo($radek["email"]);?></td>
        </tr>
    <?php
        }
    ?>
</table>

<?php
include_once(__DIR__ . "/../../includes/_footer.php");
?>
