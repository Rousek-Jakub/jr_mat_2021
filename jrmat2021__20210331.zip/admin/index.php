<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();

$section = C_SECTION_ADMIN;

//tady logiku co udělat než pošlu nějaký data, jestli ho vubec posilat
$data = db_execute("SELECT * FROM ". C_TABLE_REQUEST ." WHERE status='new' ORDER BY create_date ASC");
$arr_data = $data->fetchAll();
//print_r($arr_data);
include_once(__DIR__ . "/../includes/_header.php");
include_once(__DIR__ . "/_menu.php");
?>




<?php
include_once(__DIR__ . "/../includes/_footer.php");
?>
