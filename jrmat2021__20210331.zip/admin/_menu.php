
<!--
<nav>
    <ul>
        <li><a href="/admin/requests/" class="
        <?php if($partition == "requests") echo("active"); ?>
        ">Žádosti nové</a></li>
        <li><a href="/admin/requests/permited.php/" class="
        <?php if($partition == "permited") echo("active"); ?>
        ">Žádosti Schválené</a></li>
        <li><a href="/admin/requests/rejected.php/" class="
        <?php if($partition == "rejected") echo("active"); ?>
        ">Žádosti Zamítnuté</a></li>
    </ul>
</nav>
-->
