<?php
$nazev = $ic = $jmeno = $prijmeni = $email = "";


    // overeni, byla data odeslana a ze se jedna o data z naseho formulare


    if ( POST("submit_btn") == "Register" ) {
        // formular byl odeslany, muzeme validovat
        
        $nazev = POST("company_name");
        $ic = POST("ic");
        $jmeno = POST("first_name");
        $prijmeni = POST("surname");
        $email = POST("email");

        //JSOU VSECHNY VYPLNENE?
        if($nazev == "" || $ic == "" || $jmeno == "" || $prijmeni == "" || $email == ""){
            // chybove hlaseni uzivateli
            $err = "Prosíme, vyplňte všechny položky formuláře.";
        } else {
            
            // validovat na blacklist znaky
            //if ( Validator::ValidujBlacklist($nazev) === false ) $err = "Název obsahuje nepovolené znaky";
            if ( Validator::ValidujWhitelist($nazev) === false ) $err = "Název obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($jmeno) === false ) $err = "Jméno obsahuje nepovolené znaky";
            elseif ( Validator::ValidujWhitelist($prijmeni) === false ) $err = "Příjmení obsahuje nepovolené znaky";

            if ( $err == "" ) {

            // jedem dal, validujeme zadana data
            if(Validator::ValidujCislo($ic, 8)){
                //je pouzite?
                
                if(is_existing_ic($ic) === true){
                    $err = "Toto IČ již v našem systému evidujeme.";
                } else {
                    //validace emailové adresy
                    if(Validator::ValidujEmail($email)){    
                        if(is_existing_email($email)){
                            $err = "Tento email již v našem systému evidujeme.";
                        } else {
                            //ulozit do dtb
                            $result = zapis_registraci_do_databaze($ic, $email, $jmeno, $prijmeni, $nazev);
                            if($result === false){

                                $err = "Při zpracování vašeho požadavku se vyskytla chyba";
                                } else {
                                    redirect("registration_request_result.php");
                                }
                            
                        }

                    } else {
                        $err = "Prosíme o správné vyplnění e-mailové adresy ve formuláři.";
                    }

             }

               
            } else {
            $err = "Prosíme o správné vyplnění IČ ve formuláři.";
            }

        }

        }

    } else {
        // formular nebyl odeslany
    }

?>