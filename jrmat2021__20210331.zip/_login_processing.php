<?php
 $heslo = $email = "";


    // overeni, byla data odeslana a ze se jedna o data z naseho formulare


    if ( POST("submit_btn") == "Login" ) {
        // formular byl odeslany, muzeme validovat
        $email = POST("username");
        $heslo = POST("password");

        //JSOU VSECHNY VYPLNENE?
        if($email == "" || $heslo == ""){
            // chybove hlaseni uzivateli
            $err = "Prosíme, vyplňte všechny položky formuláře.";
        } else {
            //validovat na injekce do sql atd


            //je v databazi??
            if(is_valid_login_data($email, $heslo) === true){
                //platna data muze se prihlasit
                echo("ok");
                $result = log_me($email);
                if($result === false){
                    $err = "Chyba při zpracování požadavku";
                } else {
                    //vytvořená session a teď s ní pracovat
                    redirect("/home");
                }
            } else {
                $err = "Byly zadány neplatné přihlašovací údaje.";
            }





        }
    }

?>