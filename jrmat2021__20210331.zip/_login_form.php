<div id="login_window">
    <h1>Přihlášení</h1>

    <?php include(__DIR__ . "/includes/_msg.php"); ?>
 
    <form method="POST">
        <p class="input_text">E-mail:</p>
        <input type="text" placeholder="E-mail" name="username" class="login-input" ><br>
        <p class="input_text">Heslo: </p>
        <input type="password" placeholder="Heslo" name="password" class="login-input" ><br>
        <!--
        <label class="container">
            <span>Pamatovat si mě</span>
            <input type="checkbox" checked="checked">
            <span class="checkmark"></span>
        </label>
-->
        <button id="submit-button" type="submit" name="submit_btn" value="Login">Pokračovat</button>
    </form>
    <p class="">Ještě nemáte účet? <a href="/registration_request.php">Zaregistrujte se!</a></p>
</div>  