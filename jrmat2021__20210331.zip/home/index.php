<?php
require_once(__DIR__ . "/../includes/page_init.php");

//overeni typu uzivatele a jeho prava
require_user_login();

// nacist aktualni rezerace
$arr_pars = array();
$q = "select * from " . C_TABLE_RESERVATIONS . " where ( CURRENT_TIMESTAMP between since and till ) ";
if ( C_USER_IS_MANAGER ) {
	$q .= " and vehicle_id in ( select id from " . C_TABLE_VEHICLES . " where company_id = ? ) ";
	$arr_pars[] = C_USER_COMPANY_ID;
}
if ( C_USER_IS_USER ) {
	$q .= " and user_id = ? ";
	$arr_pars[] = C_USER_ID;
}
$q .= " order by till asc;";
$result = db_execute($q, $arr_pars);
if ( $result === false ) $err = "Chyba při načítání dat";
$arr_rezervace = db_fetch_all($result);

// nacist posledni tankovani
$arr_pars = array();
$q = "select * from " . C_TABLE_DATA . " ";
if ( C_USER_IS_MANAGER ) {
	$q .= " and vehicle_id in ( select id from " . C_TABLE_VEHICLES . " where company_id = ? ) ";
	$arr_pars[] = C_USER_COMPANY_ID;
}
if ( C_USER_IS_USER ) {
	$q .= " and user_id = ? ";
	$arr_pars[] = C_USER_ID;
}
$q .= " order by record_date desc limit 5;";
$result = db_execute($q, $arr_pars);
if ( $result === false ) $err = "Chyba při načítání dat";
$arr_tankovani = db_fetch_all($result);

if ( C_USER_IS_MANAGER || C_USER_IS_ADMIN ) {

	// nacist dle stk
	$q = "select * from " . C_TABLE_VEHICLES . " where vehicle_inspection_validity_till > now() ";
	if ( C_USER_IS_MANAGER ) {
		$q .= " and vehicle_id in ( select id from " . C_TABLE_VEHICLES . " where company_id = ? ) ";
		$arr_pars[] = C_USER_COMPANY_ID;
	}
	$q .= " order by vehicle_inspection_validity_till asc limit 5;";
	$result = db_execute($q, $arr_pars);
	if ( $result === false ) $err = "Chyba při načítání dat";
	$arr_stk = db_fetch_all($result);
}

$body_class = "home";
$section = C_SECTION_HOME;

include_once(__DIR__ . "/../includes/_header.php");

?>


<h2>Aktuální rezervace</h2>

<?php if ( count($arr_rezervace) > 0 ) { ?>
    <table class="simple-form-table data-table-home">
		<?php foreach ( $arr_rezervace as $radek ) {
			$auto = nacti_auto($radek["vehicle_id"]);
			$user = nacti_uzivatele($radek["user_id"]);
			?>
            <tr>
                <td><?php echo($auto["plate_number"]); ?></td>
                <td><?php echo($auto["producer"] . " " . $auto["model"]); ?></td>
                <td><?php echo($user["name"] . " " . $user["surname"]); ?></td>
                <td class="taRight"><?php echo(date_create($radek["since"])->format("j. n. Y")); ?></td>
                <td class="taRight"><?php echo(date_create($radek["till"])->format("j. n. Y")); ?></td>
                <td></td>
            </tr>
		<?php } ?>
    </table>
    <p class="links">
        <a href="/reservations" title="Vypsat všechny rezervace">Vypsat všechny rezervace</a>
        <a href="/reservations/add_reservation.php" title="Vytvořit novou rezervaci">Vytvořit novou rezervaci</a>
    </p>
<?php } ?>

<h2>Poslední tankování</h2>

<?php if ( count($arr_tankovani) > 0 ) { ?>
    <table class="simple-form-table data-table-home">
		<?php foreach ( $arr_tankovani as $radek ) {
			$auto = nacti_auto($radek["vehicle_id"]);
			$user = nacti_uzivatele($radek["user_id"]);
			?>
            <tr>
                <td><?php echo($auto["plate_number"]); ?></td>
                <td><?php echo($auto["producer"] . " " . $auto["model"]); ?></td>
                <td><?php echo($user["name"] . " " . $user["surname"]); ?></td>
                <td><?php echo($radek["refueling_place"]); ?></td>
                <td><?php echo($radek["fuel_type_refueled"]); ?></td>
                <td class="taRight"><?php echo(number_format($radek["refuelled_litres"], 2, ",", "")); ?> l</td>
                <td class="taRight"><?php echo(date_create($radek["record_date"])->format("j. n. Y")); ?></td>
                <td></td>
            </tr>
		<?php } ?>
    </table>
    <p class="links">
        <a href="/data" title="Vypsat všechna tankování">Vypsat všechna tankování</a>
        <a href="/data/add_data.php" title="Vytvořit nový záznam">Vytvořit nový záznam</a>
    </p>
<?php } ?>

<?php if ( C_USER_IS_MANAGER || C_USER_IS_ADMIN ) { ?>
    <h2>Nejbližší konec platnosti STK</h2>
	<?php if ( count($arr_stk) > 0 ) { ?>
        <table class="simple-form-table data-table-home">
			<?php foreach ( $arr_stk as $radek ) {
				?>
                <tr>
                    <td><?php echo($radek["plate_number"]); ?></td>
                    <td><?php echo($radek["producer"] . " " . $radek["model"]); ?></td>
                    <td><?php echo($radek["fuel_type"]); ?></td>
                    <td class="taRight"><?php echo(number_format($radek["travelled_kilometers"], 0, ",", " ")); ?> km</td>
                    <td class="taRight"><?php echo(date_create($radek["vehicle_inspection_validity_till"])->format("j. n. Y")); ?></td>
                    <td></td>
                </tr>
			<?php } ?>
        </table>
        <p class="links">
            <a href="/cars" title="Vypsat všechna vozidla">Vypsat všechna vozidla</a>
            <a href="/cars/add_car.php" title="Vytvořit nové vozidlo">Vytvořit nové vozidlo</a>
        </p>
	<?php } ?>
<?php } ?>


<?php include_once(__DIR__ . "/../includes/_footer.php"); ?>
