<?php

$companies = nacti_firmy();

//if ( $err != "" ) echo($err);

?>

<form method="POST" action="">

    <table class="simple-form-table">
        <tr>
            <td>Jméno:</td>
            <td><input type="text" name="name" placeholder="asdasd" value="<?php echo($jmeno); ?>"></td>
        </tr>
        <tr>
            <td>Příjmení:</td>
            <td><input type="text" name="surname" placeholder="asdasd" value="<?php echo($prijmeni); ?>"></td>
        </tr>
        <tr>
            <td>E-mail:</td>
            <td><input type="text" name="email" placeholder="asdasd" value="<?php echo($email); ?>"></td>
        </tr>

		<?php if ( C_USER_IS_ADMIN ) { ?>
            <tr>
                <td>Společnost:</td>
                <td>
                    <select name="company_id">
						<?php

						foreach ( $companies as $radek ) {
							?>
                            <option value="<?php echo($radek['id']); ?>"> <?php echo($radek['company_name']); ?> </option>

							<?php
						}

						?>
                    </select>
                </td>
            </tr>
			<?php
		}
		?>
    </table>

    <input type="hidden" name="id" value="<?php echo($id); ?>">

    <button type="submit" name="add_user" value="submit">Přidat</button>
</form>