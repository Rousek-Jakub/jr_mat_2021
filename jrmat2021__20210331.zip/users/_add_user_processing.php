<?php
$jmeno = $id = $prijmeni = $email =  $company_id = "";

    // overeni, byla data odeslana a ze se jedna o data z naseho formulare

    if ( POST("add_user") == "submit" ) {
        // formular byl odeslany, muzeme validovat
        $jmeno = POST("name");
        $prijmeni = POST("surname");
        $email = POST("email");
        $id = POST('id');
        $company_id = POST('company_id');

        
        //JSOU VSECHNY VYPLNENE?
        if($jmeno == "" || $prijmeni == "" || $email == ""){
            // chybove hlaseni uzivateli
            $err = "Prosíme, vyplňte všechny položky formuláře.";
        } else {

      

        if ( Validator::ValidujWhitelist($jmeno) === false ) $err = "Jméno obsahuje nepovolené znaky";
        elseif ( Validator::ValidujWhitelist($prijmeni) === false ) $err = "Příjmení obsahuje nepovolené znaky";

        // validace id uzivatele
        if ( $id !="" ) {
            // u admina validujeme existenci uzivatele
            if ( C_USER_IS_ADMIN ) {
                if ( !is_valid_user_id($id) ) $err = "Nevalidni identifikator uzivatele";
            } elseif ( C_USER_IS_MANAGER ) {
                // u managera validujeme existenci uzivatele a jeho prislusnost
                if ( !is_valid_user_id($id) || !is_user_belong_to_manager($id, C_USER_ID) ) $err = "Nevalidni identifikator uzivatele";
            }
        }

        // validace id spolecnosti
        if ( $err == "" ) {

            // u admina validujeme existenci spolecnosti
            if ( C_USER_IS_ADMIN ) {
                if ( !is_existing_company($company_id) ) $err = "Nevalidni identifikator společnosti";
            } elseif ( C_USER_IS_MANAGER ) {
                // u managera validujeme existenci spolecnosti a jeji prislusnost
                if ( !is_existing_company($company_id) || !is_company_belong_to_user($company_id, C_USER_ID) ) $err = "Nevalidni identifikator společnosti";
            }
        }
            

        if ( $err == "" ) {
        }

        // validace odeslanych dat
        if ( $err == "" ) {

            //validace emailové adresy
            if ( Validator::ValidujEmail($email) ) {    
                if ( is_existing_email($email) ){
                    $err = "Tento email již v našem systému evidujeme.";
                } 
            } else {
                // neni validni adresa
                $err = "E-mailova adresa neni platna";
            }

        }
    }
        if ( $err == "" ) {
            // data jsou validni muzeme je zpracovat
            $password = GenerujEnglishLikeString(8);
            $url = 
            $password_hash = sha1($password);
            $uid = UUID::v5();

            $q = "INSERT INTO " . C_TABLE_USERS . "(id, email, password, name, surname, required_password_change, create_date, role, company_id) VALUES (?, ?, ?, ?, ?, 1, now(), ?, ?)";
            $result = db_execute($q, [$uid, $email, $password_hash, $jmeno, $prijmeni, C_ROLE_USER, $company_id]);
            if($result === false){
                $err = "Chyba při zpracování údajů";
            } else {
                //bylo zapsano odesilam email
                
                $subject = "Informace o vytvoření účtu v systému CRAMS";
                $login_url = C_BASE_URL . "/login.php";
                
                $body = file_get_contents(__DIR__ . "/user_create.txt");
                $body = str_replace("<!--(login)-->", $email, $body);
                $body = str_replace("<!--(password)-->", $password, $body);
                $body = str_replace("<!--(jmeno)-->", $jmeno, $body);
                $body = str_replace("<!--(prijmeni)-->", $prijmeni, $body);
                $body = str_replace("<!--(login_url)-->", $login_url, $body);

                $result = odeslatEmail($email, $subject, $body);
                if ( $result === false ) $msg = "Uživatel byl vytvořen, ale nepodařilo se odeslat e-mail na jeho adresu.";
                else $msg = "Uživatel byl vytvořen a byl mu odeslán email s instrukcemi.";

                //hlaseni o vysledku akce a nasledny redirect.
                redirect("index.php?msg_success=" . urlencode($msg));

            }            

        }

    } else {
        // formular nebyl odeslany
    }

?>