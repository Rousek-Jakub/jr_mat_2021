<?php
require_once(__DIR__ . "/../includes/page_init.php");
//overeni typu uzivatele a jeho prava
require_user_login();
$section = "users";
//$partition = "permited";
//tady logiku co udělat než pošlu nějaký data, jestli ho vubuc posilat
$arr_pars = array();

$q = "SELECT * FROM " . C_TABLE_USERS;
if ( C_USER_ROLE == C_ROLE_MANAGER || C_USER_ROLE == C_ROLE_USER ) {
	$q .= " WHERE company_id = ? ";
	$arr_pars[] = C_USER_COMPANY_ID;
}
$q .= " ORDER BY create_date DESC";

//$data = db_execute("SELECT * FROM ". C_TABLE_USERS ." ORDER BY create_date DESC");
$data = db_execute($q, $arr_pars);

$arr_data = $data->fetchAll();
//print_r($arr_data);
include_once(__DIR__ . "/../includes/_header.php");

//include_once(__DIR__ . "/../_menu.php");

include_once(__DIR__ . "/../includes/_msg.php");
?>

<?php if ( C_USER_IS_MANAGER || C_USER_IS_ADMIN ) { ?>
    <p class="pb10"><a href="add_user.php" class="a-btn a-btn-new">Přidat uživatele</a></p>
<?php } ?>

<table class="data-table data">
    <thead>
    <tr>
        <td>Název Firmy</td>
        <td>Jméno</td>
        <td>Příjmení</td>
        <td>E-mail</td>
        <td class="taRight">Datum schválení žádosti</td>
    </tr>
    </thead>

	<?php

	foreach ( $arr_data as $radek ) {
		?>
        <tr>
            <td><?php echo(db_getSimpleValue("SELECT company_name FROM " . C_TABLE_COMPANIES . " WHERE id = ? ", [$radek['company_id']])); ?></td>
            <td><?php echo($radek["name"]); ?></td>
            <td><?php echo($radek["surname"]); ?></td>
            <td><?php echo($radek["email"]); ?></td>
            <td class="taRight"><?php echo (date_create(db_getSimpleValue("SELECT create_date FROM " . C_TABLE_USERS . " WHERE id = ? ", [$radek['id']])))->format("j. n. Y H:i"); ?></td>
        </tr>
		<?php
	}
	?>
</table>

<?php
include_once(__DIR__ . "/../includes/_footer.php");
?>
