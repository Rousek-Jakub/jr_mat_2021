<?php
     require_once(__DIR__ . "/includes/page_init.php");
     

     //co mi přišlo z formu
     //print_r($_POST);

     //validace dat (všech)
     
     

     //validace ič(formát, existence)
     $q = "SELECT count(ic) FROM " . C_TABLE_REQUEST . " WHERE ic ='" . $_POST['ic'] . "'";
     $result = db_getSimpleValue($q);
     if ( (int)$result === 0 ) {
          //zapsat do db
          // vygenerovat uuid jako identifikator pozadavku
          $uuid = UUID::v5();
          // 9e2a12e0-88d3-5e68-bc26-fdfe94fea1f7
          //echo($uuid); exit();
          $q = "INSERT INTO " . C_TABLE_REQUEST ." (id, company_name, ic, name, surname, email, status) values (
               '$uuid', 
               '" . db_escape($_POST["company_name"]) . "', 
               '" . db_escape($_POST["ic"]) . "', 
               '" . db_escape($_POST["first_name"]) . "', 
               '" . db_escape($_POST["surname"]) . "', 
               '" . db_escape($_POST["email"]) . "', 
               'new'
          );";

          // zapis
          $result = db_execute($q);
          if ( $result === false ) echo("error");
          else {
               // bylo zapsano, je potreba redirect jinam, aby user nemohl udělat znovu refresh a tim vyvolat novy zapis
               $url = "registration_request_result.php?tx=" . urlencode("Data byla uložena");
               redirect($url);
          }
          } else { 
               echo("Požadavek na registraci této společnosti již existuje.");
     }
     
     //validace emailu (formát, existence)


     //

     //zkouska existence pripojeni databaze
     //var_dump($pdo);
?>